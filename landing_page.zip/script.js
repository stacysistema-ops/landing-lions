document.getElementById('cta-btn').addEventListener('click', function() {
    alert('Gracias por unirte. ¡Pronto más sorpresas!');
});